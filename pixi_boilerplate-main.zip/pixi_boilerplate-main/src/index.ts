import { GameApplication } from './GameApplication';
import './Main.css'

const app = new GameApplication();
